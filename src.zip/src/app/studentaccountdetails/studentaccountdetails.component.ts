import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentaccountdetails',
  templateUrl: './studentaccountdetails.component.html',
  styleUrls: ['./studentaccountdetails.component.css']
})
export class StudentaccountdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
