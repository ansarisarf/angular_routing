import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { RouterModule, Routes } from '@angular/router';
import { StudentComponent } from './student/student.component';
import { StudentdetailsComponent } from './studentdetails/studentdetails.component';
import { StudentregistrationComponent } from './studentregistration/studentregistration.component';
import { StudentaccountdetailsComponent } from './studentaccountdetails/studentaccountdetails.component';
import { StudentparentdetailsComponent } from './studentparentdetails/studentparentdetails.component';
import { BookComponent } from './book/book.component';
import { BookdetailsComponent } from './book/bookdetails/bookdetails.component';



// console.log("Module loaded..");
// const routes: Routes = [
//   //{ path: '', redirectTo: 'home',pathMatch:'full' },
//   {path:'',component:DashboardComponent},
//   { path: 'home', component: DashboardComponent },
//   { path: 'contactus', component: ContactusComponent },
//   { path: 'contactus/:id', component: ContactusComponent },
//   { path: 'aboutus', component: AboutusComponent },
//   { path: 'aboutus/:id', component: AboutusComponent },
//   { path: 'aboutus/:id/:name', component: AboutusComponent },
//  // { path: '**', component: PagenotfoundComponent }
// ];

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ContactusComponent,
    AboutusComponent,
    PagenotfoundComponent,
    StudentComponent,
    StudentdetailsComponent,
    StudentregistrationComponent,
    StudentaccountdetailsComponent,
    StudentparentdetailsComponent,
    BookComponent,
    BookdetailsComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
  // RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    //MaterialmoduleModule
  ],
  providers: [], //MessageService
  bootstrap: [AppComponent]
})
export class AppModule {
  // constructor(){
  //   console.log("Module constructor called !!");
  // }
 }
