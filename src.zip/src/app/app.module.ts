import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ContactusComponent } from './contactus/contactus.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';



console.log("Module loaded..");
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ContactusComponent,
    AboutusComponent,
    PagenotfoundComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    //MaterialmoduleModule
  ],
  providers: [], //MessageService
  bootstrap: [AppComponent]
})
export class AppModule {
  // constructor(){
  //   console.log("Module constructor called !!");
  // }
 }
