import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  constructor(private router:Router, private _route:ActivatedRoute,private _location:Location) {
    // console.log(this.router.getCurrentNavigation().extras.state);

   }

  ngOnInit(): void {

   // console.log(this.router.getCurrentNavigation().extras.state);
   //console.log(this._location.getState());
   console.log(history.state);
  }

  // isfinalsubmit(){
  //   return confirm("Are you sure to navigate ? (about us component)");
  // }

  canDeactivate(){
    return confirm("Are you sure to navigate ? (about us component)");
  }

}
