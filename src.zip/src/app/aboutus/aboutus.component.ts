import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  constructor(private _route:ActivatedRoute) {
    // this._route.queryParams.subscribe(param=>{
    //   alert(param['firstname']);
    //   alert(param['lastname']);
    // })
   }

  ngOnInit(): void {
  }

  // isfinalsubmit(){
  //   return confirm("Are you sure to navigate ? (about us component)");
  // }

  canDeactivate(){
    return confirm("Are you sure to navigate ? (about us component)");
  }

}
