import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-studentparentdetails',
  templateUrl: './studentparentdetails.component.html',
  styleUrls: ['./studentparentdetails.component.css']
})
export class StudentparentdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
