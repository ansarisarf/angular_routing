import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ActivatechildGuard } from './activatechild.guard';
import { AuthGuard } from './auth.guard';
import { BookComponent } from './book/book.component';
import { BookdetailsComponent } from './book/bookdetails/bookdetails.component';
import { ContactusComponent } from './contactus/contactus.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DeactivateGuard } from './deactivate.guard';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { ResolvGuard } from './resolv.guard';
import { StudentComponent } from './student/student.component';
import { StudentaccountdetailsComponent } from './studentaccountdetails/studentaccountdetails.component';
import { StudentdetailsComponent } from './studentdetails/studentdetails.component';
import { StudentparentdetailsComponent } from './studentparentdetails/studentparentdetails.component';
import { StudentregistrationComponent } from './studentregistration/studentregistration.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: '', component: DashboardComponent },
  { path: 'home', component: DashboardComponent },
  { path: 'contactus', component: ContactusComponent,canDeactivate:[DeactivateGuard]},
  { path: 'aboutus', component: AboutusComponent,canDeactivate:[DeactivateGuard]},

  { path: 'book', component: BookComponent },
  { path: 'bookdetails/:id', component: BookdetailsComponent,resolve:{objbook:ResolvGuard} },

  // {
  //   path: 'student',canActivateChild:[ActivatechildGuard],
  //   children: [
  //     { path: '', component: StudentComponent },
  //     { path: 'details',component:StudentdetailsComponent},     //,canActivate:[AuthGuard]
  //     { path: 'registration', component: StudentregistrationComponent },
  //   ]


  // }

  {
    path: 'student',
    children: [
      { path: '', component: StudentComponent },
      { path: 'registration', component: StudentregistrationComponent },

      {
        path:'',canActivateChild:[ActivatechildGuard],
        children:[
          { path: 'details',component:StudentdetailsComponent},     //,canActivate:[AuthGuard]
         
        ]
      }
      
    ]


  }


  // { path: 'contactus/:id', component: ContactusComponent },
  // { path: 'aboutus/:id', component: AboutusComponent },
  // { path: 'aboutus/:id/:name', component: AboutusComponent },
  // { path: '**', component: PagenotfoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
