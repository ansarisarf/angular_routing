export class Book {
    id:number;
    name:string;
    price:number;
    description:string;
}

