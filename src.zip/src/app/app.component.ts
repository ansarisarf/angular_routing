
import { Component, HostListener, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],


})
export class AppComponent {
  title = 'Hello Sahosoft Solutions';
  abc = "contactus";
  constructor(private _router : Router){

  }
  ngOnInit() {

  }

  gotocontact(){
    //this._router.navigate(['contactus']);
    this._router.navigate(['contactus',501]);
  }

}
