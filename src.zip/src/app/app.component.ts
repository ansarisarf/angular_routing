
import { Component, HostListener, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],


})
export class AppComponent {
  title = 'Hello Sahosoft Solutions';
  abc = "contactus";
  myClass="active home";
  constructor(private _router: Router) {

  }
  ngOnInit() {

  }

  getclass(){
    return "active home";
  }
  gotocontact() {
    //this._router.navigate(['contactus']);
    this._router.navigate(['contactus', 501]);
  }

  gotoaboutusnew() {
    this._router.navigateByUrl("aboutus", { state: { empcode: 101, empname: 'Pawan Kumar' } });
  }

}
