import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AboutusComponent } from './aboutus/aboutus.component';

export interface cancomponentdeactivate{
  canDeactivate:()=>Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree ;
}

@Injectable({
  providedIn: 'root'
})

export class DeactivateGuard implements CanDeactivate<cancomponentdeactivate> {
  canDeactivate(
    component: cancomponentdeactivate,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    let isSubmitted: Boolean = false;
    // if (isSubmitted == false) {
    //   return confirm("Are you sure to leave this page ?");
    //   // return false;
    // }
     return component.canDeactivate ? component.canDeactivate() : true;
  }

}

// export class DeactivateGuard implements CanDeactivate<AboutusComponent> {
//   canDeactivate(
//     component: AboutusComponent,
//     currentRoute: ActivatedRouteSnapshot,
//     currentState: RouterStateSnapshot,
//     nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
//     let isSubmitted: Boolean = false;
//     // if (isSubmitted == false) {
//     //   return confirm("Are you sure to leave this page ?");
//     //   // return false;
//     // }
//      return component.isfinalsubmit ? component.isfinalsubmit() : true;
//   }

// }



// export class DeactivateGuard implements CanDeactivate<unknown> {
//   canDeactivate(
//     component: unknown,
//     currentRoute: ActivatedRouteSnapshot,
//     currentState: RouterStateSnapshot,
//     nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
//     let isSubmitted: Boolean = false;
//     if (isSubmitted == false) {
//       return confirm("Are you sure to leave this page ?");
//       // return false;
//     }
//     return true;
//   }

// }
