import { Injectable } from '@angular/core';
import { Observable,of } from 'rxjs';
import { Book } from './book';
import 'rxjs-compat/add/observable/of';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private BOOKS: Book[] = [
    { id: 100, name: 'Angular 14', price: 2000, description: 'Angular book' },
    { id: 101, name: 'React JS', price: 2200, description: 'React book' },
    { id: 102, name: 'Node JS', price: 1500, description: 'Node book' },
    { id: 103, name: 'AWS', price: 2500, description: 'AWS book' },
    { id: 104, name: 'Dot net core', price: 1500, description: 'Dot net book' },

  ]

  constructor() { }

  getBooks():Observable<Book[]>{
    //return of(this.BOOKS);
    return Observable.of(this.BOOKS);
  }
}
